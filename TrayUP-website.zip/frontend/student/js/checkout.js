(function () {
  document.getElementById("app-header").innerHTML = trayComponents.header();

  const cart = trayStorage.get("trayup-cart", []);
  const loginUrl = "./login.html?next=checkout.html";
  const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;"
  })[character]);
  const rupees = (value) => `₹${Number(value).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
  const paidStatuses = new Set(["paid", "captured", "completed", "success"]);
  const summaryRowStyle = "display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #eee";

  function confirmationUrl(order) {
    const data = order?.data || {};
    const paymentStatus = String(data.payment_status || "").toLowerCase();
    return paidStatuses.has(paymentStatus)
      ? `./order-placed-animation.html?receipt=${encodeURIComponent(data.order_number || "Pending")}`
      : "./confirmation.html";
  }

  // Before the order exists, the total is only an estimate from the cart.
  const estimatedTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const totalEl = document.getElementById("checkout-total");
  const totalNote = document.getElementById("total-note");
  const summaryEl = document.getElementById("summary");
  const paymentOptionsEl = document.getElementById("payment-options");
  const paymentPanel = document.getElementById("upi-payment-panel");

  function renderEstimate() {
    totalEl.textContent = rupees(estimatedTotal);
    totalNote.textContent = "Estimate. The server confirms the final amount when you place the order.";
    summaryEl.innerHTML = cart.length
      ? cart.map((item) => `<div style="${summaryRowStyle}"><span>${item.qty} × ${escapeHtml(item.name)}</span><strong>${rupees(item.price * item.qty)}</strong></div>`).join("")
      : `<p style="color:var(--muted)">Your cart is empty</p>`;
  }

  // Once the server has created the order, show its lines and total: this is what gets charged.
  function renderServerOrder(order) {
    totalEl.textContent = rupees(order.total_paise / 100);
    totalNote.textContent = "Confirmed by the server. This is the amount you will be charged.";
    summaryEl.innerHTML = (order.items || []).map((line) => `<div style="${summaryRowStyle}"><span>${Number(line.quantity)} × ${escapeHtml(line.item_name)}</span><strong>${rupees(line.line_total_paise / 100)}</strong></div>`).join("");
  }

  renderEstimate();
  document.getElementById("summary-food-images").innerHTML = cart.map((item) => `
<figure class="checkout-food-image">
 <img src="${escapeHtml(item.image || "")}" alt="${escapeHtml(item.name)}" loading="eager" onerror="this.style.display='none'">
 <figcaption><strong>${escapeHtml(item.name)}</strong><span>Qty ${Number(item.qty) || 1}</span></figcaption>
</figure>`).join("");

  const form = document.getElementById("checkout-form");
  const submitButton = form.querySelector('button[type="submit"]');
  const idleLabel = submitButton.textContent;
  const nameInput = document.getElementById("name");
  const phoneInput = document.getElementById("phone");
  const phoneError = document.getElementById("phone-error");
  const claimButton = document.getElementById("submit-payment-claim");
  const utrInput = document.getElementById("utr-number");
  const paymentMessage = document.getElementById("upi-payment-message");
  let paymentMethodsLoaded = false;
  let hasPaymentMethod = false;
  let phoneValidationRequested = false;

  // The server order for this checkout. Once it exists, retrying payment reuses it instead of
  // creating another order.
  let serverOrder = null;
  let orderDetails = null;
  // Sent as Idempotency-Key. Kept across retries until the order is created, so a double tap or
  // a dropped response cannot create two orders.
  let idempotencyKey = null;
  let submitting = false;

  function newIdempotencyKey() {
    if (window.crypto?.randomUUID) return window.crypto.randomUUID();
    const bytes = new Uint8Array(16);
    window.crypto.getRandomValues(bytes);
    return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  function setBusy(busy, busyLabel) {
    submitting = busy;
    submitButton.disabled = busy || !paymentMethodsLoaded || !hasPaymentMethod;
    if (busy) submitButton.textContent = busyLabel;
    else submitButton.textContent = serverOrder ? "Retry payment" : idleLabel;
  }

  function renderPaymentMethods(methods) {
    const choices = [];
    if (methods?.upi?.enabled) {
      choices.push(`
        <label class="payment-option">
          <input type="radio" name="payment_method" value="upi" required>
          <span class="payment-logo phonepe">UPI</span>
          <span><strong>UPI / QR</strong><small>PhonePe, GPay, Paytm or any UPI app</small></span>
        </label>`);
    }
    if (methods?.sandbox?.enabled) {
      choices.push(`
        <label class="payment-option">
          <input type="radio" name="payment_method" value="sandbox" required>
          <span class="payment-logo gpay">✓</span>
          <span><strong>Test Sandbox</strong><small>Instant simulated payment for development</small></span>
        </label>`);
    }

    if (!choices.length) {
      paymentOptionsEl.innerHTML = '<p role="status">No digital payment methods are currently available.</p>';
      return false;
    }

    paymentOptionsEl.innerHTML = choices.join("");
    const selected = methods?.payment_provider === "sandbox" && methods?.sandbox?.enabled
      ? "sandbox"
      : choices.length === 1 && !methods?.upi?.enabled ? "sandbox" : "upi";
    const defaultOption = paymentOptionsEl.querySelector(`input[value="${selected}"]`) ||
      paymentOptionsEl.querySelector('input[type="radio"]');
    if (defaultOption) defaultOption.checked = true;
    return true;
  }

  async function loadPaymentMethods() {
    paymentOptionsEl.textContent = "Loading payment options…";
    try {
      const response = await trayPayment.getMethods();
      hasPaymentMethod = renderPaymentMethods(response?.data || {});
      paymentMethodsLoaded = true;
      submitButton.disabled = !hasPaymentMethod;
      if (!hasPaymentMethod) trayNotify("No digital payment methods are available right now.");
    } catch (error) {
      paymentOptionsEl.innerHTML = error.status === 401
        ? "<p>Sign in is required to continue to payment.</p>"
        : '<p role="alert">Could not load payment options. Please refresh and try again.</p>';
      submitButton.disabled = error.status !== 401;
      trayNotify(error.message || "Could not load payment options.");
    }
  }

  function validatePhone(showError) {
    const valid = trayValidation.phone(phoneInput.value);
    phoneError.hidden = valid || !showError;
    phoneInput.setAttribute("aria-invalid", String(!valid && showError));
    return valid;
  }

  async function prefillStudentDetails() {
    try {
      const response = await trayAuth.currentUser();
      const student = response?.data;
      if (String(student?.role || "").toUpperCase() !== "STUDENT") return;
      nameInput.value = student.name || "";
      phoneInput.value = student.mobile_number || "";
      validatePhone(false);
    } catch (error) {
      if (error.status !== 401) {
        trayNotify(error.message || "Could not load your account details.");
      }
    }
  }

  nameInput.addEventListener("input", () => nameInput.removeAttribute("aria-invalid"));
  phoneInput.addEventListener("blur", () => validatePhone(true));
  phoneInput.addEventListener("input", () => {
    if (phoneValidationRequested || !phoneError.hidden) validatePhone(true);
  });

  function completeOrder(order, details) {
    const saved = {
      success: true,
      data: {
        order_number: order.order_number,
        order_status: order.order_status,
        payment_status: order.payment_status,
        payment_method: details.paymentMethod,
        payment_provider: details.paymentProvider,
        total_paise: order.total_paise,
        items: cart,
        instructions: details.instructions,
        student_name: details.name,
        phone_number: details.phone,
        created_at: order.created_at
      }
    };
    trayStorage.remove("trayup-cart");
    trayStorage.set("trayup-last-order", saved);
    window.location.href = confirmationUrl(saved);
  }

  function setAppLink(id, uri) {
    const link = document.getElementById(id);
    if (!uri) {
      link.hidden = true;
      return;
    }
    link.href = uri;
    link.hidden = false;
  }

  function showUpiPayment(data) {
    document.getElementById("upi-order-summary").textContent =
      `Order ${data.order_number || serverOrder.order_number} · ${rupees(data.amount_paise / 100)}`;
    setAppLink("open-phonepe", data.phonepe_uri);
    setAppLink("open-gpay", data.gpay_uri);
    setAppLink("open-paytm", data.paytm_uri);
    setAppLink("open-upi", data.upi_uri);

    const qr = document.getElementById("upi-qr");
    if (data.qr_svg_url) {
      qr.src = new URL(data.qr_svg_url, window.location.origin).href;
      qr.hidden = false;
    } else {
      qr.hidden = true;
    }
    paymentMessage.textContent = "After paying, return here and tap “I Have Paid”.";
    paymentPanel.hidden = false;
    submitButton.hidden = true;
    nameInput.disabled = true;
    phoneInput.disabled = true;
    document.getElementById("instructions").disabled = true;
    paymentOptionsEl.querySelectorAll("input").forEach((input) => { input.disabled = true; });
  }

  function handleError(error) {
    if (error.status === 401) {
      window.location.href = loginUrl;
      return;
    } else if (error.code === "ORDER_EXPIRED" || error.code === "ORDER_NOT_PAYABLE_REFUND_REQUIRED") {
      serverOrder = null;
      orderDetails = null;
      renderEstimate();
      trayNotify(error.message);
    } else trayNotify(error.message || "The order could not be placed");

    setBusy(false);
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    if (submitting) return;

    setBusy(true, "Checking sign in…");
    try {
      const response = await trayAuth.currentUser();
      if (String(response?.data?.role || "").toUpperCase() !== "STUDENT") {
        window.location.href = loginUrl;
        return;
      }
    } catch (error) {
      if (error.status === 401) {
        window.location.href = loginUrl;
        return;
      }
      setBusy(false);
      trayNotify(error.message || "Could not verify your sign-in. Please try again.");
      return;
    }
    setBusy(false);

    const name = nameInput.value.trim();
    const phone = phoneInput.value.trim();
    const instructions = document.getElementById("instructions").value.trim();
    const selectedMethod = form.querySelector('input[name="payment_method"]:checked');
    if (!paymentMethodsLoaded || !hasPaymentMethod || !selectedMethod) {
      trayNotify("Payment options are not available. Please refresh and try again.");
      return;
    }
    const paymentMethod = selectedMethod.value;
    const details = {
      name,
      phone,
      instructions,
      paymentMethod,
      paymentProvider: paymentMethod === "sandbox" ? "Test Sandbox" : "UPI / Soundbox"
    };

    phoneValidationRequested = true;
    const validPhone = validatePhone(true);
    if (!trayValidation.required(name)) {
      nameInput.setAttribute("aria-invalid", "true");
      nameInput.focus();
      trayNotify("Please enter your name");
      return;
    }
    if (!validPhone) {
      phoneInput.focus();
      return;
    }
    if (!cart.length) {
      trayNotify("Your cart is empty");
      return;
    }

    setBusy(true, "Placing order…");
    try {
      if (!serverOrder) {
        idempotencyKey = idempotencyKey || newIdempotencyKey();
        const response = await trayApi.post("/orders", {
          items: cart.map((item) => ({ menu_item_id: item.id, quantity: item.qty }))
        }, { headers: { "Idempotency-Key": idempotencyKey } });
        serverOrder = response.data;
        idempotencyKey = null;
        renderServerOrder(serverOrder);
      }
      orderDetails = details;

      if (paymentMethod === "sandbox") {
        setBusy(true, "Completing test payment…");
        const response = await trayPayment.completeSandbox(serverOrder.id);
        if (response?.data?.refund_required) {
          submitting = false;
          hasPaymentMethod = false;
          submitButton.hidden = true;
          paymentOptionsEl.innerHTML = 'This payment needs review. <a href="./tracking.html">Check Track orders</a>.';
          trayNotify("This order needs staff review. Check Track orders before trying again.");
          return;
        }
        completeOrder({ ...serverOrder, ...response.data }, {
          ...details,
          paymentMethod: "sandbox",
          paymentProvider: "Test Sandbox"
        });
        return;
      }

      setBusy(true, "Preparing UPI payment…");
      const response = await trayPayment.initiateUpi(serverOrder.id);
      showUpiPayment(response.data);
      setBusy(false);
    } catch (error) {
      handleError(error);
    }
  });

  claimButton.addEventListener("click", async () => {
    if (!serverOrder || submitting) return;
    const utrNumber = utrInput.value.trim();
    if (utrNumber && !/^[A-Za-z0-9]{12}$/.test(utrNumber)) {
      paymentMessage.textContent = "Enter a 12-character alphanumeric UTR, or leave it blank.";
      utrInput.focus();
      return;
    }

    submitting = true;
    claimButton.disabled = true;
    paymentMessage.textContent = "Submitting your payment claim…";
    try {
      const response = await trayPayment.submitUpiClaim(serverOrder.id, utrNumber);
      completeOrder({ ...serverOrder, ...response.data }, {
        ...orderDetails,
        paymentMethod: "upi_soundbox",
        paymentProvider: "UPI / Soundbox"
      });
    } catch (error) {
      paymentMessage.textContent = error.message || "Could not submit the payment claim.";
      claimButton.disabled = false;
    } finally {
      submitting = false;
    }
  });

  prefillStudentDetails();
  loadPaymentMethods();
})();
